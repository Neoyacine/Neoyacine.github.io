let cita0, cita1, cita2, cita3, cita4, cita5, cita6;
cita0 = "Comme la Hongrie, le monde informatique a une langue qui lui est propre. Mais il y a une différence. Si vous restez assez longtemps avec des Hongrois, vous finirez bien par comprendre de quoi ils parlent. <br> Dave Barry"
cita1 = "L'enseignement de l'informatique ne peut faire de personne un programmeur expert plus que l'étude des pinceaux et du pigment peut faire de quelqu'un un peintre expert. - Eric S. Raymond";
cita2 = "Je m'en fous si ça marche sur votre machine ! Nous ne livrons pas votre machine ! - Inconnu.e";
cita3 = "Codez comme si la personne qui finit par maintenir votre code est un psychopathe violent qui sait où vous vivez. - Jeff Atwood";
cita4 = "N’importe quel idiot peut écrire du code qu'un ordinateur peut comprendre. Les bons programmeurs écrivent du code que les humains peuvent comprendre. - Martin Fowler";
cita5 = "N'importe quel code que vous avez écrit depuis 6 mois ou plus sans y regarder pourrait tout aussi bien avoir été écrit par quelqu'un d'autre - Alan Eagleson";
cita6 = "Aujourd’hui, la programmation est devenue une course entre le développeur, qui s’efforce de produire de meilleures applications à l’épreuve des imbéciles et l’univers, qui s’efforce de produire de meilleurs imbéciles. Pour l’instant, l’univers a une bonne longueur d’avance — Rich Cook";


const citation = document.getElementById("citations");
// citation.innerHTML = cita0
let citations = [cita0, cita1, cita2, cita3, cita4, cita5, cita6];

console.log(citations)
let slideIndex = 0;


function addSlide(n){ 
    // if (slideIndex == -1){
    //     slideIndex = citation.length -1;
    // }
    if ( slideIndex >= citations.length -1)
        slideIndex = -1;
    else if ( slideIndex < 0)
        slideIndex = citations.length ;
   

    slideIndex += n;
    console.log(slideIndex);
    citations[slideIndex];
    citation.innerHTML = `${citations[slideIndex]}`
    
}

